/*ArrayList<Integer> al2 = new ArrayList<Integer>(al);
        System.out.println(al2);


        System.out.println(al.get(0));
        System.out.println(al.get(3));
        //System.out.println(al.get(10));Index 10 out of bounds for length 5

        //E.set(int index, E element);
        System.out.println(al.set(0,11));
        System.out.println(al.set(3,33));
        //System.out.println(al.set(10,33));Index 10 out of bounds for length 5
        System.out.println(al);

        // indexof
        System.out.println(al.indexOf(33));
        System.out.println(al.indexOf(11));
        //lastIndexOf()
        System.out.println(al.lastIndexOf(10));
        System.out.println(al.lastIndexOf(40));
        
     //public int remove(index)
        System.out.println(al.remove(2));
        System.out.println(al);

        //int size();
        System.out.println(al.size());

        //boolean isEmpty()
        System.out.println(al.isEmpty());

        //add multiple elements with Array.asList in constructor
        ArrayList<String> AL = new ArrayList<String>(Arrays.asList("Hello","Ciao","Bonjour"));
        System.out.println(AL);
        ArrayList<String> AL3 = new ArrayList<String>(Arrays.asList("ery","abc","bcdf"));
        AL.addAll(AL3);
        System.out.println(AL);
        System.out.println(AL3);
        AL3.clear();
        System.out.println(AL3);
*/